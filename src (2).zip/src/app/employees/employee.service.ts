import { Injectable } from '@angular/core';
import { Employee } from '../models/empolyee.model';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/delay';

@Injectable()
export class EmployeeService {
    private listEmployees: Employee[] = [
        {
            id: 1,
            name: 'Henry',
            gender: 'Male',
            contactPreferance: 'Phone',
            phoneNumber: 2132398373,
            dateOfBirth: new Date('11/20/1972'),
            department: 'IT',
            isActive: true,
            photoPath: 'assets/images/image2.jpg'
        },
        {
            id: 2,
            name: 'Mary',
            gender: 'Female',
            contactPreferance: 'Phone',
            phoneNumber: 2132398373,
            dateOfBirth: new Date('11/20/1970'),
            department: 'HR',
            isActive: true,
            photoPath: 'assets/images/image1.jpg'
        },
        {
            id: 3,
            name: 'John',
            gender: 'Male',
            contactPreferance: 'Phone',
            phoneNumber: 2132398373,
            dateOfBirth: new Date('11/20/1975'),
            department: 'HR',
            isActive: true,
            photoPath: 'assets/images/image2.jpg'
        }
    ];

    getEmployees():Observable<Employee[]> {
        return Observable.of(this.listEmployees).delay(2000);
    }
    getEmployee(id: number): Employee {
        return this.listEmployees.find(e => e.id === id);
    }

    save(employee: Employee) {
        this.listEmployees.push(employee);
    }
}