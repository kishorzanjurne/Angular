export class Department{
    
}